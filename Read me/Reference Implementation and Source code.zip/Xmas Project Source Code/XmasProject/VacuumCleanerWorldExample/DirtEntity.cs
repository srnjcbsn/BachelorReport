﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmasEngineModel.EntityLib;

namespace VacuumCleanerWorldExample
{
    //Here we define a dirt entity
	public class DirtEntity : XmasEntity
	{
	}
}
