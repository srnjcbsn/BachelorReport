﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmasEngineModel.Management;

namespace VacuumCleanerWorldExample.Events
{
	public class VacuumSuckedEvent : XmasEvent
	{
	}
}
