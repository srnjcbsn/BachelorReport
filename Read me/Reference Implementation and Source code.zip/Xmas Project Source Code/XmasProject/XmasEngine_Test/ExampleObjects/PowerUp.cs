﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XmasEngineModel.EntityLib;

namespace XmasEngine_Test.ExampleObjects
{
	public class PowerUp : XmasEntity
	{
		public PowerUp()
		{
			

		}
	}
}
