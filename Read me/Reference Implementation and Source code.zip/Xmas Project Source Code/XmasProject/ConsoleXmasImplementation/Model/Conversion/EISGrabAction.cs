﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XmasEngineExtensions.EisExtension.Model;

namespace ConsoleXmasImplementation.Model.Conversion
{
	public class EISGrabAction : EISAction
	{
	}
}
