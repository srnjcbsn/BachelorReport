namespace ConsoleXmasImplementation.Model.Entities
{
	public class Package : ConsoleEntity 
	{
		public Package () 
		{
		}
	}
}

