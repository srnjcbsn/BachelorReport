﻿using ConsoleXmasImplementation.Controller;
using ConsoleXmasImplementation.View;
using XmasEngine;
using XmasEngineController;
using XmasEngineExtensions.EisExtension.Controller.AI;
using XmasEngineExtensions.TileExtension;
using XmasEngineModel;
using XmasEngineModel.Management;
using XmasEngineView;

namespace ConsoleXmasImplementation
{
	public class ConsoleFactory : XmasModelFactory
	{


		
	}
}