using XmasEngineExtensions.EisExtension.Model;

namespace XmasEngineExtensions.TileEisExtension.ActionTypes
{
	public class EISMoveUnit : EISAction
	{
	}
}