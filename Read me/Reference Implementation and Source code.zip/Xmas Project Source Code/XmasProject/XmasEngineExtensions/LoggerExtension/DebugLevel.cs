using System;

namespace XmasEngineExtensions.LoggerExtension
{
	public enum DebugLevel
	{
		None,
		Critical,
		Error,
		Info,
		Timing,
		All
	};
}

