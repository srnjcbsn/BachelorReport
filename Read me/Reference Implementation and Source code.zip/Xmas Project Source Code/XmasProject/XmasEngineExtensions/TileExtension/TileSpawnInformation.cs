using System;
using XmasEngineModel.World;

namespace XmasEngineExtensions.TileExtension
{
	public class TileSpawnInformation : EntitySpawnInformation
	{
		public TileSpawnInformation(TilePosition pos) : base(pos)
		{ }
	}
}

