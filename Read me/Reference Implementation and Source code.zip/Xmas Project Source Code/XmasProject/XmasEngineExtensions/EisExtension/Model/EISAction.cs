using JSLibrary.IiLang.DataContainers;

namespace XmasEngineExtensions.EisExtension.Model
{
	public abstract class EISAction : IilAction
	{
	}
}