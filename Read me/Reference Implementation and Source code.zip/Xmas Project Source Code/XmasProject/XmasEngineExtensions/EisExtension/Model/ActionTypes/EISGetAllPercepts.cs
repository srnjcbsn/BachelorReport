namespace XmasEngineExtensions.EisExtension.Model.ActionTypes
{
	public class EISGetAllPercepts : EISAction
	{
	}
}