﻿using System;

namespace XmasEngineModel.Exceptions
{
	public class ForceStopEngineException : Exception
	{
	}
}