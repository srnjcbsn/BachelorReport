﻿namespace XmasEngineModel.Interfaces
{
	public interface IStartable
	{
		void Start();
		void Initialize();
	}
}