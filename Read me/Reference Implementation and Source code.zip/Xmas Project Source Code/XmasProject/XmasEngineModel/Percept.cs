﻿namespace XmasEngineModel
{

    /// <summary>
    /// A percept meant to be percieved by agents
    /// </summary>
	public abstract class Percept : XmasObject
	{
	}
}