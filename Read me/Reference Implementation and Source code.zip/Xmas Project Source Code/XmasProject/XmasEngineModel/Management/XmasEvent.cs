﻿using System;

namespace XmasEngineModel.Management
{

    /// <summary>
    /// Extend this class to create new types of events for the engine
    /// </summary>
	public abstract class XmasEvent : EventArgs
	{
	}
}