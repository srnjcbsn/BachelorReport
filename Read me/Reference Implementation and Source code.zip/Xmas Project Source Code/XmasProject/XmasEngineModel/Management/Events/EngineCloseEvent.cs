﻿namespace XmasEngineModel.Management.Events
{
	internal class EngineCloseEvent : XmasEvent
	{
	}
}