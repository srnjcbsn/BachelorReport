﻿namespace XmasEngineModel.Management.Interfaces
{
	internal class GameManager
	{
	}
}