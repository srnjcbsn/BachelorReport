﻿namespace XmasEngineModel.Management.Interfaces
{
	internal interface ITriggerContainer
	{
	}
}