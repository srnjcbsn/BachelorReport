namespace JSLibrary.IiLang
{
	public class SingleParameter
	{
	}
}