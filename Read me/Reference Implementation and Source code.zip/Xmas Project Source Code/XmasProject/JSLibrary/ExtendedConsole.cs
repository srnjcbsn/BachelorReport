﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JSLibrary
{
    public class ExtendedConsole
    {
        public static readonly object ConsoleWriterLock = new object();
    }
}
